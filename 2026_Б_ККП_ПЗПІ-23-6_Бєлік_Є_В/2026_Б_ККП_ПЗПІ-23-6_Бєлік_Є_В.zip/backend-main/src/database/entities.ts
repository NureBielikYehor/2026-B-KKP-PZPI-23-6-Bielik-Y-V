import { User } from '../users/entities/user.entity';
import { Post } from '../posts/entities/post.entity';
import { PopularPostSnapshot } from '../posts/entities/popular-post-snapshot.entity';
import { PopularPostSnapshotItem } from '../posts/entities/popular-post-snapshot-item.entity';
import { PostTextPart } from '../posts/entities/post-text-part.entity';
import { PostAudioProcessingJob } from '../posts/entities/post-audio-processing-job.entity';
import { PostAudioAnalysis } from '../posts/entities/post-audio-analysis.entity';
import { PostListenSession } from '../posts/entities/post-listen-session.entity';
import { Category } from '../categories/entities/category.entity';
import { PostCategory } from '../categories/entities/post-category.entity';
import { PostReaction } from '../reactions/entities/post-reaction.entity';
import { PostComment } from '../comments/entities/post-comment.entity';
import { PopularCommentSnapshot } from '../comments/entities/popular-comment-snapshot.entity';
import { PopularCommentSnapshotItem } from '../comments/entities/popular-comment-snapshot-item.entity';
import { CommentReaction } from '../reactions/entities/comment-reaction.entity';
import { Subscription } from '../subscriptions/entities/subscription.entity';
import { Transaction } from '../subscriptions/entities/transaction.entity';
import { Card } from '../subscriptions/entities/card.entity';
import { Admin } from '../admin/entities/admin.entity';
import { AdminRefreshToken } from '../admin/entities/admin-refresh-token.entity';
import { PostComplaint } from '../complaints/entities/post-complaint.entity';
import { Follower } from '../followers/entities/follower.entity';
import { AndroidPushToken } from '../notifications/entities/android-push-token.entity';
import { BrowserPushSubscription } from '../notifications/entities/browser-push-subscription.entity';
import { PushNotificationSettings } from '../notifications/entities/push-notification-settings.entity';
import { Notification } from '../notifications/entities/notification.entity';
import { NotificationEvent } from '../notifications/entities/notification-event.entity';
import { RefreshToken } from '../auth/entities/refresh-token.entity';
import { MailRequestCounter } from '../mail/entities/mail-request-counter.entity';

export const ENTITIES = [
  User,
  Post,
  PopularPostSnapshot,
  PopularPostSnapshotItem,
  PostTextPart,
  PostAudioProcessingJob,
  PostAudioAnalysis,
  PostListenSession,
  Category,
  PostCategory,
  PostReaction,
  PostComment,
  PopularCommentSnapshot,
  PopularCommentSnapshotItem,
  CommentReaction,
  Subscription,
  Transaction,
  Card,
  Admin,
  AdminRefreshToken,
  PostComplaint,
  Follower,
  AndroidPushToken,
  BrowserPushSubscription,
  PushNotificationSettings,
  Notification,
  NotificationEvent,
  RefreshToken,
  MailRequestCounter,
];
